from setuptools import setup

setup(

    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Juan Ignacio Alonso Flieller",
    author_email="zalbak87@gmail.com",
    packages=["Calculos","Calculos.redondeo_potencia"]
)
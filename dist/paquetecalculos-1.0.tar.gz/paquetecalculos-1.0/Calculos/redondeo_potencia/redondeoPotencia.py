def potencia(base,exponente):
    print("El resultado de la divicion es: ",base**exponente)

def redondear(numero):
    print("El resultado de el redondeo es: ",round(numero))